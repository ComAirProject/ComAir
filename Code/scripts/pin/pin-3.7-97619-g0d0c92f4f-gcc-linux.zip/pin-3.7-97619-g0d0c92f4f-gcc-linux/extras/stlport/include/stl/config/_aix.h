#define _STLP_PLATFORM "AIX"

#define _STLP_USE_UNIX_IO
