using _STLP_OLD_IO_NAMESPACE::ostream;
using _STLP_OLD_IO_NAMESPACE::endl;
using _STLP_OLD_IO_NAMESPACE::ends;
using _STLP_OLD_IO_NAMESPACE::flush;

// using _STLP_OLD_IO_NAMESPACE::ws;
